package gameCodes;

public class start {

	public static void main(String[] args) {
		Deck deck = new Deck();
		deck.Deck();
//		deck.shuffle();
//		
//		deck.getDeck();
//		setShuffledDeck(deck.getDeck());

	}

}
