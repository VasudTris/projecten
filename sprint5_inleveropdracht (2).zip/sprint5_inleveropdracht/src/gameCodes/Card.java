package gameCodes;

import enums.Suit;
import enums.Value;

public class Card {
	private Suit s;
	private Value v;
	
	public Card(Suit s, Value v) {
		this.setS(s);
		this.setV(v);
	}
//	 public Value getValue() {
//	        return value;
//	    }
//
//	    public Suit getSuit() {
//	        return suit;
//	    }
//
//	    public String toString() {
//	        return value + " of " + suit;
//	    }
	public String toString() {
        return v + " " + s;
    }

	public Suit getS() {
		return s;
	}

	public void setS(Suit s) {
		this.s = s;
	}

	public Value getV() {
		return v;
	}

	public void setV(Value v) {
		this.v = v;
	}
	
	public boolean inHigherOrEqual(Card c) {
		
		if(this.v.numericalValue >= c.v.numericalValue) {
			return true;
		}
		else {
			return false;
		}
		
		
	}

}
