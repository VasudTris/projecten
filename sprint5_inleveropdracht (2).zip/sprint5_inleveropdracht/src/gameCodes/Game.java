package gameCodes;


import java.util.Scanner;

public class Game {
	private int score;
	private Card currentCard;
    private Card nextCard;
    private Deck deck = new Deck();
    private Scanner sc = new Scanner(System.in);
	
	
	public void game() {
  }
	
	
    public void gameTurn() {
	   currentCard = deck.getNextCard();
	   System.out.println("score: " + score + "\nDe kaart is: " + currentCard.toString());
	   String answer = sc.nextLine();
	
	   nextCard = deck.getNextCard();
	   
	   if(answer.equals("hoger") && nextCard.inHigherOrEqual(currentCard)) {
		   correct();
	   } else if(answer.equals("lager") && !nextCard.inHigherOrEqual(currentCard)){
		   correct();
	   } else {
		   incorrect();
	   }
	
    
    
    }

    public void correct() {
    	System.out.println("goed gegokt! De kaart was: " + nextCard.toString() + "\n");
    	score++;
	
    }
    
    public void incorrect() {
    	System.out.println("fout gegokt! De kaart was: " + nextCard.toString() + "\n");
    	score--;
    }
    
    public boolean stillPlayable() {
    	if(deck.AreCardsLeft()) {
    		return true;
    	}else {
    	    return false;	
    	}
		
    	
    }
    
    public int getScore() {
		return score;
    	
    }
    
    public void gameDone() {
    	System.out.println("spel afgelope babee... score : " + score);
    }

}


