package gameCodes;

import java.util.ArrayList;
import java.util.Collections;

import enums.Suit;
import enums.Value;

public class Deck {
	private ArrayList<Card> cards = new ArrayList<Card>();

    // Maak het deck aan
	
	//void is toegevoegd
    public void Deck() {
        for (Suit s : Suit.values()) {
            for (Value v : Value.values()) {
            	Card card = new Card(s, v);
            			
                cards.add(new Card(s, v));
                
            }
            
       }
        Collections.shuffle(cards);
    }
    

	 public Card getNextCard() {
		 cards.remove(0);
		 
		return cards.get(0);
		
		 
	 }
	 
	 public ArrayList<Card> getCards(){
		return cards;
		 
	 }
	 
	 public boolean AreCardsLeft() {
	 if(cards.size() > 2) {
		 return true;
	 } else {
		 return false;
	 }
	 }

}
