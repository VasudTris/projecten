package main;




import gameCodes.Game;

public class Starter {

	public static void main(String[] args) {
		Game a = new Game();
		
		while(a.stillPlayable()) {
			a.gameTurn();
		}
		a.gameDone();
		
			

	}

	

}
