<link rel="stylesheet" href="CSS/500.css">
<h5>Internal Server error !</h5>
<h1>5</h1>
<h1>00</h1>
<div class="box">
    <span></span><span></span>
    <span></span><span></span>
    <span></span>
</div>
<div class="box">
    <span></span><span></span>
    <span></span><span></span>
    <span></span>
</div>
<p> We're unable to find out what's happening! We suggest you to
    <br />
    <a href="iindex.php">Go Back</a>
    or visit here later.
</p>