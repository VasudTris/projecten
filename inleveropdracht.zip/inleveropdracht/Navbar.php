<div class="container-fluid bg-white">
    <div class="container">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-primary">
                <div class="container">
                    <img src="Images/eye.png">
                    <div class="lk" style="color: cornflowerblue ;">
                        <div style="font-size:30px;">
                            <b>
                                Spyservice
                                <br>
                                <span style="color: #28507A ;">
                                    International
                                </span>
                            </b>
                        </div>
                    </div>



                    <link rel="stylesheet" href="CSS/navbar.css">

                    <button class="navbar-toggler bg-secondary" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navmenu">
                        <span class="navbar-toggler-icon">

                        </span>
                    </button>
                    <div class="collapse navbar-collapse" id="navmenu">
                        <ul class="navbar-nav ms-auto">

                            <li class="nav-item">
                                <a  href="iindex.php" class="nav-link" style="font-size: 20px"><b> home </b></a>
                            </li>
                            <li class="nav-item">
                                <a href="overons.php" class="nav-link" style="font-size: 20px"><b> over ons </b></a>
                            </li>
                            <li class="nav-item">
                                <a  href="document.php" class="nav-link" style="font-size: 20px" ><b> documenten </b></a>

                            </li>
                            <li class="nav-item">
                                <a  href="contact.php" class="nav-link" style="font-size: 20px" ><b> contact </b></a>

                            </li>

                        </ul>
                    </div>
                </div>
            </nav>
        </div>


    </div>
</div>
