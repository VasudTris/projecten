<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Home</title>
    <link rel="stylesheet" href="CSS/index.css">
     
</head>

<body>
    <!-- Navbar -->
    <header>
   <?php include('Navbar.php'); ?>
</header>
    <!-- Backgound -->
    <img class="img-fluid w-100" src="images/indrex.png" alt="">




    <div class="container">
        <div class="row">
            <div class="col">
                <div class="kleur1">
                    <h1 style="color: cornflowerblue ;">Welkom bij Spyservices <span style="color:black;">International </span></h1>
                <p>wij lichten mensen op, let op,  je locatie ligt nu in mijn handen..</p>
                </div>



            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">

        </script>
</body>


</html>