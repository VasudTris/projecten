package starter;

import account.Account;
//import account.BankAccount;
import account.CreditAccount;
import rest.Bank;
import rest.Person;

public class Starter {


	


	public static Account account;
	protected static Person persoon;
	public static Bank bA;
	public static CreditAccount cA;
	public static String n = "juriaan";
	public static String n2 = "Al Mahbir";
	public static String n3 = "Cyka Blyat";
	
    public static Bank bank = new Bank("vis");
	public static void main(String[] args) {
		
//		//Person ad = new Person();
//        
//		//choose credit card or bank
//		//Person kan = new Person();
//		//kan.transfer(50);
//		setbA(bank);
//	    setAccount(new Account(null, n, 100));
//		setPersoon(new Person());
//		Bank.Bsnnr1();
//		
//		
//		//transfer tussen 2 bankaccounts, type het bedrag
//		//bank.transfer(50);
//		
//		//setbA(new BankAccount(persoon, n));
//		//setcA(new CreditAccount(persoon, n));
//		
//		
//		
//		
//		
//
//        
//		setbA(new Bank("bank"));
//		setAccount(new Account(null, n2, 100));
//		setPersoon(new Person());
//		Bank.Bsnnr();
//		//setbA(new BankAccount(persoon, n));
//		//setcA(new CreditAccount(persoon, n));
//		
//		
//		setbA(new Bank("credit card"));
//		setAccount(new Account(null, n3, 100));
//		setPersoon(new Person());
//		Bank.Bsnnr2();
//	    //setbA(new BankAccount(persoon, n));
//		//setcA(new CreditAccount(persoon, n));
//		bank.findingBank();
//		
		 
		
		 //ad.Bankk();
		bank.transfer(0, 0, 42069);

	}

	
	

	

	
	

	

}
