package account;

import java.util.Random;

import starter.Starter;

public class CreditAccount extends Account{
	


	public CreditAccount(int fromAccountNr) {
		super(fromAccountNr);
		// TODO Auto-generated constructor stub
	}

	double creditLimit = 1000;
	double creditAmount;
	int securityCode;
	Random r = new Random();
	

	
	
	 double getSpendingLimit() {
		return creditAmount;
		
	}
	 
	void payCredit(){
		 
	 }
	
	public static CreditAccount getcA(CreditAccount cA) {
		return cA;
	}

	public static void setcA(CreditAccount cA) {
		Starter.cA = cA;
	}
	
	
	

}
