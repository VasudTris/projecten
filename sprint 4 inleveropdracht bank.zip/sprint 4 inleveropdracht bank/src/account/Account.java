package account;

import rest.Person;
import starter.Starter;

public class Account {
	
	
	
	public interface fromAccount {

	}

	public static int nextAccountNumber = 1000;
	public int accountnummer;
	private String type;
	private int Balance = 1200;

	public Account(Person persoon, String type, int Balance) {
		
			this.setType(type);
			   System.out.println("Accountnaam: " + type);
			   System.out.println("Account nummer: " + nextAccountNumber);
			   System.out.println("balance " + Balance);
			
			
			   accountnummer = nextAccountNumber;
			   nextAccountNumber++;
			 
			  
		
	}
	
	
	
	
	

	public void deposit(double amount) {
		if(amount > 0) {
			Balance += amount;
			return;
		}
		
		
	}

	
	

	public static Account getAccount() {
		return getAccount();
	}

	public static void setAccount(Account account) {
		Starter.account = account;
		
	}




	
	public Account(int fromAccountNr) {
		this.accountNumber =fromAccountNr;
		
		
	}

















	public boolean withdraw(double amount) {
		
		if (amount > 0 && Balance >= amount) {
			Balance -= amount;
			return true;
		}
		
		return false;
		
	}
	//public double balance = 100;
	//public double amount = 20;
	public int accountNumber;
	
	

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}


































	public void setBalance(int balance) {
		Balance = balance;
	}






	







		
	
	
}
