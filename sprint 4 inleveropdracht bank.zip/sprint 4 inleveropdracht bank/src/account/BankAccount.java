package account;


import rest.Bank;

import starter.Starter;


public class BankAccount extends Account {
	

	
	public BankAccount(int fromAccountNr) {
		super(fromAccountNr);
		// TODO Auto-generated constructor stub
	}

	public static Bank getBank() {
		return getBank();
	}

	public static void setBank(Bank bank) {
		Starter.bank = bank;
	}

	public static Bank getbA(Bank bA) {
		return bA;
	}

	public static void setbA(Bank bank2) {
		Starter.bA = bank2;
	}



}
