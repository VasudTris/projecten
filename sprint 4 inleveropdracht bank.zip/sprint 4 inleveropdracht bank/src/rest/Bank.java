package rest;

import java.util.ArrayList;

import account.Account;

    public class Bank extends Person {
	private ArrayList<Account> accounts = new ArrayList<>();
	static String money = "Geld: ";
	public static int geldAlmahbir = 100;
	public static int geldCyka = 100;
	public static int geldJuriaan = 100;
	
	//Kies hier als eigenaar de transfer tussen 2 accounts door de int te veranderen naar hun int naam
	public void transfer(int fromAccountNr, int toAccountNr, int amount ){
		//Account.nextAccountNumber++;
		Account fromAccount = getAccountByNr(fromAccountNr);
		Account toAccount = getAccountByNr(toAccountNr);
		
		
		
		if(fromAccount != null && toAccount != null){
			
			boolean withdrawSucces = fromAccount.withdraw(amount);
			if(withdrawSucces){
				toAccount.deposit(amount);
	            System.out.println("Funds successfully transfered.");
	            System.out.println("_______________________________");
	            return;
	            }
			

            
            System.out.println("Insufficient funds");
            System.out.println("_______________________________");
        } 
		
        
	



	   return;
	}
	


	
	private Account getAccountByNr(int fromAccountNr) {
		
		return new Account(fromAccountNr);
	}




	public static void Bsnnr()
	{
		System.out.println("BSN: " + Person.bsn1 );
		int a = 69;
		
		System.out.println("Leeftijd: " + a);
		System.out.println(money + geldAlmahbir);
		
		System.out.println("__________________________________");
	}
	public static void Bsnnr1()
	{
		System.out.println("BSN: " + Person.bsn );
		int aids = 145;
		
		System.out.println("Leeftijd: " + aids);
		System.out.println(money + geldJuriaan);
		System.out.println("__________________________________");
	}
	
	public static void Bsnnr2()
	{
		System.out.println("BSN: " + Person.bsn2 );
		int don = 90;
		System.out.println("Leeftijd: " + don);
		System.out.println(money + geldCyka);
		System.out.println("__________________________________");
	}
	

	public  Bank(String name) {
	
	   System.out.println(name + " is gemaakt met: Rabobank" );
	   
	
	   
	}
	
	

	
	public Account getAccountByNumber(int accountNumber, int nextAccountNumber){
	for(Account a: accounts){
		
	    if(a.accountNumber == nextAccountNumber){
	    	
	    	

	    	
	    return a;
	  }
	}
	return null;
	}
	public boolean registerAccount(Person persoon, String type, int Balance){
	//Account a = new Account(persoon, type);
	
	accounts.add(new Account(persoon,"juriaan", Balance));
	accounts.add(new Account(persoon,"al mahbir", Balance));
	accounts.add(new Account(persoon,"cyka blyat", Balance));
	
	
	return true;
	}
	
	public  void findingBank() {
		 //------------------
		//enter number
		int accNr = 1002;
		//--------------
		switch(accNr) {
		  case 1000:
				System.out.println("__________________________________");
				System.out.println("Find account by number");
				System.out.println("__________________________________");
			  System.out.println("Bank");
			 System.out.println("Account nummer: " + 1000);
			 System.out.println("Accountnaam: Juriaan");
			 int a = 69;
				
				System.out.println("Leeftijd: " + a);
			 System.out.println("BSN: " + Person.bsn );
		    break;
		  case 1001:
				System.out.println("__________________________________");
				System.out.println("Find account by number");
				System.out.println("__________________________________");
			  System.out.println("Bank");
				 System.out.println("Account nummer: " + 1001);
				 System.out.println("Accountnaam: Al Mahbir");
				 int kaas = 145;
					System.out.println("Leeftijd: " + kaas);
				 System.out.println("BSN: " + Person.bsn1 );
		    break;
		  default:
				System.out.println("__________________________________");
				System.out.println("Find account by number");
				System.out.println("__________________________________");
			  System.out.println("Credit Account");
				 System.out.println("Account nummer: " + 1002);
				 System.out.println("Accountnaam: Cyka Blyat");
				 int f = 90;
					System.out.println("Leeftijd: " + f);
				 System.out.println("BSN: " + Person.bsn2 );
				
		}
	}

}
