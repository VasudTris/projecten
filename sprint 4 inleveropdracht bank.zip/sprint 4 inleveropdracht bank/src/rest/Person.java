package rest;

import starter.Starter;

public class Person extends Starter { 
	
	public static String bsn = "4RF343FRT4";
	public static String bsn1 = "3939FDF34";
	public static String bsn2 = "SGF364433FD";
	public static String credit = "Credit Card";
	

	
	
	
	public Person() {
		
		
	}
	
	public static void setPersoon(Person persoon) {
		Starter.persoon = persoon;
	}

	
	public static Person getPersoon()
	{
	
	
		return persoon;
	}



	static void account() {
	
	}
	
    
	
	 public boolean equals (Object Q) {
		return false;
		
	}
	 
	public int HashCode() {
		return 0;
	}

}
